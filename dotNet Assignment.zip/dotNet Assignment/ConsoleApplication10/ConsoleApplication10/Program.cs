﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication10
{
    class Program
    {
        public int add( int a,  int b)
        {
            a = 3;
            b = 2;
            int c = a + b;
            return c;
        }
        static void Main(string[] args)
        {
            int x, y;
            Program p = new Program();
            Console.WriteLine("Enter x value:");
            x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter y value:");
            y = Convert.ToInt32(Console.ReadLine());
            int z = p.add( x,  y);
            Console.WriteLine(z);
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.ReadLine();



        }

    }
}