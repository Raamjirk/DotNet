﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication12
{
    interface ICompany
    {
        void CompanyName();
    }
    class Company:ICompany
    {
        public  void CompanyName()
        {
            Console.WriteLine("IMCS");
        }
        public void CompanyAddress()
        {
            Console.WriteLine("Dallas");
        }
    }
    class Employee : Company
    {
        string s;
        string l;
        public Employee(string name, string sal)
        {
            s = name;
            l = sal;

        }

        public void NameofEmployee()
        {
            Console.WriteLine("Name of the Employee:"+s);
        }
        public void Salary()
        {
            Console.WriteLine("Salary of the Employee:"+l);
        }
    }
    class Program
    {
        public static void Main(string[] args)
        {
            Employee e = new Employee("Raamji","$10000000000");
            
            e.NameofEmployee();
            e.Salary();
            e.CompanyName();
            e.CompanyAddress();
            Console.ReadLine();
        }
        
    }
}
