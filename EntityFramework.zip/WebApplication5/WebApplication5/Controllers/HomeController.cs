﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication5.Models;

namespace WebApplication5.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            
            EmployeeDBContext employeeContext = new EmployeeDBContext();
            List<Employee> employees = employeeContext.Employees.ToList();
            
            return View(employees);
        }
        public ActionResult Details(int id)
        {

            EmployeeDBContext employeeContext = new EmployeeDBContext();
            Employee employees = employeeContext.Employees.Single(emp => emp.ID == id);

            return View(employees);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}